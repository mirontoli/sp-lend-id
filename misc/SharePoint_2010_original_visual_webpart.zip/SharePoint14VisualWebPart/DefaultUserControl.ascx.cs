﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace $rootnamespace$.$subnamespace$
{
    public partial class $safeitemrootname$ : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
