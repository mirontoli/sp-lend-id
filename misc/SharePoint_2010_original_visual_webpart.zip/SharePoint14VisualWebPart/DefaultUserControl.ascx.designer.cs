﻿namespace $rootnamespace$.$subnamespace$
{
    public partial class $safeitemrootname$
    {
    }
}
